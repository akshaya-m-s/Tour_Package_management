<?php

// Define file paths
$modelsPath = '../../../../models/put.php';
$headersPath = '../../../../config/header.php';

// Check if required files exist
if (!file_exists($modelsPath) || !file_exists($headersPath)) {
    handleResponse(500, 'Required files are missing');
}

// Include necessary files
require_once $modelsPath;
require_once $headersPath;

// Function to handle errors and send response
function handleResponse($statusCode, $message) {
    http_response_code($statusCode);
    echo json_encode(['error' => $message]);
    exit();
}

// Decode incoming JSON data
$data = json_decode(file_get_contents('php://input'));

// Check if the required fields are provided
if (!isset($data->id) || !isset($data->name) || !isset($data->email) || !isset($data->phone) || !isset($data->arrival_date) || !isset($data->departure) || !isset($data->number_of_days) || !isset($data->price) || !isset($data->status)) {
    handleResponse(400, 'All required fields (id, name, email, phone, arrival_date, departure, number_of_days,price,status) are required');
}


$obj = new Put();

$data = json_decode(file_get_contents('php://input'));
if (isset($data->id, $data->name, $data->email, $data->phone, $data->arrival_date, $data->departure, $data->number_of_days, $data->price,$data->status)) {
    $result = $obj->book(
        $data->id, 
        $data->name, 
        $data->email, 
        $data->phone, 
        $data->arrival_date, 
        $data->departure, 
        $data->number_of_days, 
        $data->price,
        $data->status,
        
    );
    echo json_encode($result);
} else {
    http_response_code(400);
    echo json_encode(["error" => "Invalid input"]);
}



echo json_encode($result);
?>
