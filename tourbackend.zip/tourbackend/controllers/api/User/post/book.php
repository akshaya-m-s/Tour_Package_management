<?php
// Define paths to required files
$modelsPath = '../../../../models/post.php';
$headersPath = '../../../../config/header.php';

// Check if required files exist and include them
if (!file_exists($modelsPath) || !file_exists($headersPath)) {
    handleError(500, 'Required files are missing');
}

// Require the necessary files
require_once $modelsPath;
require_once $headersPath;

// Decode the incoming JSON data
$data = json_decode(file_get_contents('php://input'));

// Function to handle errors and send response
function handleError($statusCode, $message) {
    http_response_code($statusCode);
    echo json_encode(['error' => $message]);
    exit();
}

// Check if data is null or empty
if (!$data) {
    handleError(400, 'Invalid or missing JSON payload');
}

// Validate required fields
$requiredFields = ['id', 'name', 'email', 'phone', 'arrival_date', 'departure', 'number_of_days', 'price', 'status'];
foreach ($requiredFields as $field) {
    if (empty($data->$field)) {
        handleError(400, "Missing or empty field: $field");
    }
}

// Create an instance of the Post class
$obj = new Post();

// Insert booking data into the database
$result = $obj->book($data->id, $data->name, $data->email, $data->phone, $data->arrival_date, $data->departure, $data->number_of_days, $data->price, $data->status);

// Handle errors
if ($result === false) {
    handleError(500, 'Internal server error');
}

// Send the result as a JSON response
echo json_encode($result);
?>
