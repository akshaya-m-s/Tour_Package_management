
import React, { useState } from 'react';
import axios from 'axios'; // Import Axios
import './userlog.css';

function Userlogin() {
  const [name, setName] = useState(''); // State for username
  const [password, setPassword] = useState(''); // State for password

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      const payload = { name, password };
      const response = await axios.post(
        'http://localhost/tourbackend/controllers/api/User/post/tourmanage.php', 
        payload
      );
      console.log('Login response:', response.data);

      if (response.status === 200) {
        window.location.href = '/userpanel';
      } else {
        alert('Login failed, please check your credentials.');
      }
    } catch (error) {
      console.error('Error logging in:', error);
      alert('An error occurred during login. Please try again.');
    }
  };

  return (
    <div className="big-log">
      <div className="container-log">
        <h1 className="h1">User Login</h1>
        <form className="frm" onSubmit={handleLogin}>
          <label className="lbl">Username</label>
          <input
            className="inp"
            type="text"
            required
            autoComplete="username"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />

          <label className="lbl">Password</label>
          <input
            className="inp"
            type="password"
            required
            autoComplete="current-password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />

          <button className="bt2" type="submit">
            Log In
          </button>
        </form>
      </div>
    </div>
  );
}

export default Userlogin;
