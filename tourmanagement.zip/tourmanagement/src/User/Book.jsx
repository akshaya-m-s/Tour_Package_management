import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link } from "react-router-dom";
import "./book.css";

function Book() {
  const [packages, setPackages] = useState([]);

  useEffect(() => {
    axios
      .get("http://localhost/tourbackend/controllers/api/User/Get/roomimage.php")
      .then((response) => {
        setPackages(response.data);
      })
      .catch((error) => {
        console.error("Error fetching packages:", error);
      });
  }, []);
  return (
    <div className="main-book1">
      <p className="h1two">Book Places</p>
      <div className="two-card">
        {packages.map((pkg) => (
          <div className="vehicle-card" key={pkg.id}>
            <img
              src={`http://localhost/tourbackend/controllers/api/User/upload/${pkg.file}`}
              alt={pkg.packname}
              className="vehicle-image1"
            />
            <div className="vehicle-details">
              <div className="vehicle-name">Place name: {pkg.packname}</div>
              <div className="vehicle-price">Price: ₹ {pkg.price}</div>
              <div className="vehicle-brand">City: {pkg.city}</div>
            </div>
            <Link
              to={`/twodetail`}
              state={{ id: pkg.id, price: pkg.price }}
            >
              <button className="view-button1">Book</button>
            </Link>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Book;


