import React from 'react'
import "./newreg.css"
import { Link } from 'react-router-dom'

function Newregister() {
  return (
   <>
    <div className="big-log">
         <div className="container-log">
        <h1 className='h1'>User Login</h1>
        <form className='frm'>
            <label className='lbl'>Username</label>
            <input className='inp' type="text" required autocomplete="username"/>
            
            <label className='lbl'>Password</label>
            <input className='inp' type="password" required autocomplete="current-password"/>

            <label className='lbl'>Confirm Password</label>
            <input className='inp' type="password" required autocomplete="current-password"/>
            
            <Link to={"/userlogin"}><button className='bt' type="submit">Register</button></Link>
        </form>
        
    </div>
    </div>
   </>
  )
}

export default Newregister